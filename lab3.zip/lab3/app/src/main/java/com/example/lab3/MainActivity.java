package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    firstfragment Frag1;
    secondfragment Frag2;
    Button button;

    int showingfragment =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Frag1 = new firstfragment();
        Frag2 = new secondfragment();

        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.add(R.id.clayout,Frag1);
        fragmentTransaction.commit();
        showingfragment=1;


    }
    public  void click(View view){

        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if(showingfragment==1){
            fragmentTransaction.replace(R.id.clayout,Frag2);
            showingfragment =2;
            fragmentTransaction.commit();
        }else{
            fragmentTransaction.replace(R.id.clayout,Frag1);
            showingfragment =1;
            fragmentTransaction.commit();
        }


    }

}